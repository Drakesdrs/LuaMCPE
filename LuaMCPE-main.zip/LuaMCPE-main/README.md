# LuaMCPE
Allows you run lua scripts on android devices
Based on Dolua
